// Simulasi data detak jantung (random antara 60 - 100)
function generateRandomValue() {
  return Math.floor(Math.random() * (100 - 60 + 1) + 60);
}

// Membuat grafik detak jantung dengan Chart.js
function createHeartRateChart() {
  const heartRateChart = document.getElementById('heart-rate-chart').getContext('2d');
  return new Chart(heartRateChart, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Detak Jantung',
        data: [],
        backgroundColor: 'rgba(40, 167, 69, 0.5)',
        borderColor: 'rgba(40, 167, 69, 1)',
        borderWidth: 2,
        fill: 'origin',
        lineTension: 0,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          suggestedMin: 60,
          suggestedMax: 100,
        }
      }
    }
  });
}

// Perbarui grafik detak jantung dan nilai detak jantung dengan data terbaru
function updateHeartRate() {
  const heartRateChart = createHeartRateChart();
  const heartRateValue = document.getElementById('heart-rate-value');
  const randomValue = generateRandomValue();

  heartRateChart.data.labels.push('');
  heartRateChart.data.datasets[0].data.push(randomValue);
  heartRateChart.update();

  heartRateValue.textContent = randomValue + ' bpm';
}

// Perbarui data setiap 2 detik
setInterval(function() {
  updateHeartRate();
}, 2000);
